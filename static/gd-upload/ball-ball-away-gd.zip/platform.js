'use strict';
/*
 * Platform layer, GameDistribution build. Ads come only from the GD SDK.
 * The build script sets window.BBA_CONFIG.platform to one of:
 *   This build is for GameDistribution only: no other ad network is referenced.
 * The game only talks to window.Platform; nothing in game.js knows which portal it runs on.
 */
(function () {
  const cfg = Object.assign({ platform: 'preview' }, window.BBA_CONFIG || {});
  const hooks = { adStart() {}, adEnd() {}, audio() {} }; // set by the game
  let playing = false, lastAdAt = 0, rewardOffer = null;

  function loadScript(src, attrs = {}) {
    return new Promise((res, rej) => {
      const s = document.createElement('script');
      s.src = src; s.async = true;
      for (const k in attrs) s.setAttribute(k, attrs[k]);
      s.onload = res; s.onerror = () => rej(new Error('SDK failed to load: ' + src));
      document.head.appendChild(s);
    });
  }
  // Wrap an ad call so the game is always paused + muted during it and resumed after, exactly once.
  function adWindow(run) {
    return new Promise(resolve => {
      let started = false, done = false;
      const start = () => { if (!started && !done) { started = true; hooks.adStart(); } };
      const end = result => { if (done) return; done = true; hooks.adEnd(); if (started) lastAdAt = Date.now(); resolve(result); }; // adEnd always: a portal may have paused the game on its own
      try { run(start, end); } catch (e) { console.warn('Ad error', e); end(false); }
    });
  }
  const sinceLastAd = () => (Date.now() - lastAdAt) / 1000;

  // ---------- Back-ends ----------
  const backends = {
    // Shows clearly marked placeholder ads so the ad spots can be reviewed.
    // GameDistribution — needs cfg.gdGameId (from the GD developer dashboard)
    gamedistribution: (() => {
      let pending = null;
      return {
        init: () => new Promise((resolve, reject) => {
          if (!cfg.gdGameId) { reject(new Error('Missing GameDistribution game id')); return; }
          window.GD_OPTIONS = {
            gameId: cfg.gdGameId,
            onEvent: e => {
              if (e.name === 'SDK_READY') resolve();
              if (e.name === 'SDK_GAME_PAUSE' && pending) { pending.started = true; pending.start(); }
              if (e.name === 'SDK_REWARDED_WATCH_COMPLETE' && pending) pending.rewarded = true;
              if (e.name === 'SDK_GAME_START' && pending) { const p = pending; pending = null; p.end(p.kind === 'rewarded' ? !!p.rewarded : true); }
            },
          };
          loadScript('https://html5.api.gamedistribution.com/main.min.js').catch(reject);
        }),
        hasRewarded: () => true,
        interstitial: () => adWindow((start, end) => {
          pending = { kind: 'interstitial', start, end };
          window.gdsdk.showAd()
            .then(() => { if (pending && !pending.started) { pending = null; end(false); } }) // resolved without showing an ad
            .catch(() => { pending = null; end(false); });
        }),
        rewarded: () => adWindow((start, end) => {
          pending = { kind: 'rewarded', start, end };
          window.gdsdk.showAd('rewarded')
            .then(() => { if (pending && !pending.started) { pending = null; end(false); } }) // resolved without showing an ad
            .catch(() => { pending = null; end(false); });
        }),
      };
    })(),
  };


  const be = backends[cfg.platform];
  if (!be) throw new Error('Unknown platform: ' + cfg.platform);
  let ready = false;
  const call = (fn, ...a) => { if (!ready || !fn) return; try { fn(...a); } catch (e) { console.warn('Platform call failed', e); } };

  window.Platform = {
    name: cfg.platform,
    hooks,
    // The game starts after at most 5 s even when a portal SDK never answers (ad blockers, network);
    // ads switch on as soon as the SDK reports ready.
    async init() {
      const sdk = be.init().then(() => { ready = true; }, e => console.warn('Platform SDK unavailable, running without ads', e));
      await Promise.race([sdk, new Promise(r => setTimeout(r, 5000))]);
    },
    get hasRewarded() { return ready && !!be.rewarded && !!(be.hasRewarded && be.hasRewarded()); },
    loadingDone: () => call(be.loadingDone),
    gameplayStart: () => { if (!playing) { playing = true; call(be.gameplayStart); } },
    gameplayStop: () => { if (playing) { playing = false; call(be.gameplayStop); } },
    happy: () => call(be.happy),
    get hasPlatformLeaderboard() { return ready && !!be.hasLeaderboard && be.hasLeaderboard(); },
    loadData(key) { return ready && be.loadData ? be.loadData(key) : null; },
    saveData(key, raw) { call(be.saveData, key, raw); },
    submitScore(score) { if (ready && be.submitScore) be.submitScore(score).catch(e => console.warn('Score submit failed', e)); },
    userName() { return ready && be.userName ? be.userName().catch(() => null) : Promise.resolve(null); },
    // Interstitial at a natural break (game over -> play again). Our own floor of 45 s between ads.
    interstitial() {
      if (!ready || !be.interstitial || (lastAdAt && sinceLastAd() < 45)) return Promise.resolve(false);
      return be.interstitial().catch(() => false);
    },
    // Resolves true when a rewarded ad can be offered right now
    prepareRewarded() {
      if (!this.hasRewarded) return Promise.resolve(false);
      return be.prepareRewarded ? be.prepareRewarded().catch(() => false) : Promise.resolve(true);
    },
    rewarded() {
      if (!this.hasRewarded) return Promise.resolve(false);
      return be.rewarded().catch(() => false);
    },
    showBanner(id, w, h) { const el = document.getElementById(id); if (el && ready && be.showBanner) be.showBanner(el, w, h); },
    hideBanner(id) { const el = document.getElementById(id); if (el && be.hideBanner) be.hideBanner(el); else if (el) el.hidden = true; },
  };
})();
